---
name: Forkify API quirks
description: Non-obvious compatibility behavior from the public Forkify recipe API.
---

La API pública de Forkify puede devolver URLs de imágenes con el esquema `http` aunque la aplicación se entregue mediante `https`; las imágenes deben normalizarse a `https` antes de renderizarse.

**Why:** Los navegadores pueden bloquear esas imágenes como contenido mixto y dejar tarjetas o detalles sin fotografía.

**How to apply:** Mantener esta normalización en la capa de servicio, no dispersarla entre componentes de presentación.