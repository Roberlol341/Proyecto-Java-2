# Publicar Forkify Recetas en Netlify

El repositorio ya incluye `netlify.toml` con el comando de compilación, la carpeta
publicada y la regla necesaria para la SPA.

## Opción recomendada: conectar el repositorio

1. En Netlify selecciona **Add new site** y conecta el repositorio.
2. No cambies el directorio raíz.
3. Netlify leerá automáticamente `netlify.toml`.
4. Presiona **Deploy site**.

La configuración ejecuta:

```bash
PORT=4173 BASE_PATH=/ pnpm --filter @workspace/forkify-recetas run build
```

Y publica:

```text
artifacts/forkify-recetas/dist/public
```

## Opción manual: subir la carpeta generada

Desde la raíz del proyecto ejecuta:

```bash
PORT=4173 BASE_PATH=/ pnpm --filter @workspace/forkify-recetas run build
```

Después arrastra la carpeta `artifacts/forkify-recetas/dist/public` al área de
despliegue manual de Netlify.

## Nota sobre las rutas

La redirección `/* -> /index.html` permite que la aplicación cargue correctamente
al actualizar la página o abrir directamente una URL con hash de receta.